hc <-
function (object, ...) 
UseMethod("hc")

galbraith <-
function (x, ...) 
UseMethod("radial")
radial <-
function (x, ...) 
UseMethod("radial")

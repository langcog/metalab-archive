labbe <-
function (x, ...) 
UseMethod("labbe")

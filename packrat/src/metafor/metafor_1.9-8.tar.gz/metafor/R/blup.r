blup <-
function (x, ...) 
UseMethod("blup")

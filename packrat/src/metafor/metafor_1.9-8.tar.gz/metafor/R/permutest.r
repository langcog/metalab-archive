permutest <-
function (x, ...) 
UseMethod("permutest")

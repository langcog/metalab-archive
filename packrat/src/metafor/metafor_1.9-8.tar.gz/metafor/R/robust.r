robust <-
function (x, cluster, ...) 
UseMethod("robust")

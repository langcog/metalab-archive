confint.rma.glmm <-
function (object, parm, level, digits, transf, targs, ...) 
{
    if (!is.element("rma.glmm", class(object))) 
        stop("Argument 'object' must be an object of class \"rma.glmm\".")
    stop("Method not yet implemented for objects of class \"rma.glmm\". Sorry!")
}

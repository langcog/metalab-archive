qqnorm.rma.glmm <-
function (y, ...) 
{
    if (!is.element("rma.glmm", class(y))) 
        stop("Argument 'y' must be an object of class \"rma.glmm\".")
    stop("Method not yet implemented for objects of class \"rma.glmm\". Sorry!")
}

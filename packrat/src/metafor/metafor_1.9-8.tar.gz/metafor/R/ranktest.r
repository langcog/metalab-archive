ranktest <-
function (x, ...) 
UseMethod("ranktest")

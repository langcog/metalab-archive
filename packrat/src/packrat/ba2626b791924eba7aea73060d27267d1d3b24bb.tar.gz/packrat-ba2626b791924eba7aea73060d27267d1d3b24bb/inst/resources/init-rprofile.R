#### -- Packrat Autoloader (version 0.4.7-1) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
